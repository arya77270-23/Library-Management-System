import tkinter as tk
from tkinter import ttk, messagebox
from library_db import LibraryManagementSystem
class StyledApp:
    BG_COLOR = "#F5F5F5"
    PRIMARY_COLOR = "#1494B1"
    PRIMARY_LIGHT = "#1494B1"
    TEXT_COLOR = "#181717"
    ALT_ROW_COLOR = "#FFFFFF"
    BORDER_COLOR = "#E0E0E0"
    HEADER_BG = "#EAEAEA"
    
    BASE_FONT = "Helvetica"
    FONT_NORMAL = (BASE_FONT, 10)
    FONT_BOLD = (BASE_FONT, 11, "bold")
    FONT_TITLE = (BASE_FONT, 13, "bold")
    FONT_SMALL = (BASE_FONT, 9)

    def configure_styles(self):
        style = ttk.Style(self)
        style.theme_use('clam')
        style.configure(".",
            background=self.BG_COLOR,
            foreground=self.TEXT_COLOR,
            fieldbackground=self.ALT_ROW_COLOR,
            font=self.FONT_NORMAL)
        style.configure("TNotebook",
            background=self.BG_COLOR,
            borderwidth=0)
        style.configure("TNotebook.Tab",
            font=self.FONT_BOLD,
            padding=[12, 6],
            background=self.HEADER_BG,
            foreground="#555555",
            borderwidth=0)
        style.map("TNotebook.Tab",
            background=[("selected", self.BG_COLOR)],
            foreground=[("selected", self.PRIMARY_COLOR)])
        style.configure("TFrame", background=self.BG_COLOR)
        style.configure("TLabelFrame",
            background=self.BG_COLOR,
            bordercolor=self.BORDER_COLOR,
            borderwidth=1)
        style.configure("TLabelFrame.Label",
            background=self.BG_COLOR,
            foreground=self.PRIMARY_COLOR,
            font=self.FONT_TITLE,
            padding=(0, 0, 0, 5)) 
        style.configure("TLabel", background=self.BG_COLOR, font=self.FONT_NORMAL)
        style.configure("Title.TLabel", font=self.FONT_TITLE, foreground=self.PRIMARY_COLOR)
        style.configure("TEntry",
            font=self.FONT_NORMAL,
            padding=8,
            bordercolor=self.BORDER_COLOR,
            borderwidth=1,
            relief=tk.FLAT)
        style.map("TEntry",
            bordercolor=[("focus", self.PRIMARY_COLOR)])
        style.configure("Modern.TButton",
            background=self.PRIMARY_COLOR,
            foreground="white",
            font=self.FONT_BOLD,
            padding=[15, 8],
            borderwidth=0,
            relief=tk.FLAT)
        style.map("Modern.TButton",
            background=[("active", self.PRIMARY_LIGHT),
                        ("hover", self.PRIMARY_LIGHT)])
        style.configure("Treeview",
            font=self.FONT_NORMAL,
            rowheight=30,
            background=self.ALT_ROW_COLOR,
            fieldbackground=self.ALT_ROW_COLOR,
            bordercolor=self.BORDER_COLOR,
            borderwidth=1,
            relief=tk.FLAT)
        style.configure("Treeview.Heading",
            font=self.FONT_BOLD,
            padding=8,
            background=self.HEADER_BG,
            foreground=self.TEXT_COLOR,
            relief=tk.FLAT,
            borderwidth=0)
        style.layout("Treeview", [('Treeview.treearea', {'sticky': 'nswe'})])
class LoginPage(tk.Tk, StyledApp):
    def __init__(self):
        super().__init__()
        self.db = LibraryManagementSystem()
        
        self.title("Library System Login")
        self.geometry("450x350")
        self.configure(bg=self.BG_COLOR)
        self.resizable(False, False)
        self.eval('tk::PlaceWindow . center')
        self.configure_styles()
        self.create_login_widgets()

    def create_login_widgets(self):
        main_frame = ttk.Frame(self, padding=20)
        main_frame.pack(fill="both", expand=True)

        login_frame = ttk.LabelFrame(main_frame, text="Login or Register", padding=20)
        login_frame.pack(pady=20, padx=10)
        ttk.Label(login_frame, text="Username:").grid(row=0, column=0, padx=10, pady=8, sticky='w')
        self.entry_username = ttk.Entry(login_frame, width=30)
        self.entry_username.grid(row=0, column=1, padx=10, pady=8)
        ttk.Label(login_frame, text="Password:").grid(row=1, column=0, padx=10, pady=8, sticky='w')
        self.entry_password = ttk.Entry(login_frame, width=30, show="*")
        self.entry_password.grid(row=1, column=1, padx=10, pady=8)
        button_frame = ttk.Frame(login_frame)
        button_frame.grid(row=2, column=0, columnspan=2, pady=20)

        self.btn_login = ttk.Button(button_frame, text="Login", style="Modern.TButton", command=self.attempt_login)
        self.btn_login.pack(side=tk.LEFT, padx=10)

        self.btn_register = ttk.Button(button_frame, text="Register", style="Modern.TButton", command=self.attempt_register)
        self.btn_register.pack(side=tk.LEFT, padx=10)
        self.entry_password.bind("<Return>", self.attempt_login)
        self.entry_username.bind("<Return>", self.attempt_login)

    def attempt_login(self, event=None):
        username = self.entry_username.get()
        password = self.entry_password.get()
        
        if not username or not password:
            messagebox.showwarning("Login Error", "Please enter both username and password.")
            return

        success = self.db.login_user(username, password)
        
        if success:
            self.show_main_app()
        else:
            messagebox.showerror("Login Failed", "Invalid username or password.")
    def attempt_register(self):
        username = self.entry_username.get()
        password = self.entry_password.get()
        
        success, message = self.db.register_user(username, password)
        
        if success:
            messagebox.showinfo("Success", message)
        else:
            messagebox.showerror("Registration Error", message)

    def show_main_app(self):
        self.withdraw()
        main_app = LibraryApp(self, self.db)


class LibraryApp(tk.Toplevel, StyledApp):
    def __init__(self, master_window, db_instance):
        super().__init__(master_window)
        self.master = master_window
        self.db = db_instance
        self.title("Library Management System")
        self.geometry("1100x750")
        self.configure(bg=self.BG_COLOR)
        self.create_widgets()
        self.refresh_all_tables()
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def on_close(self):
        self.master.destroy()
    def create_widgets(self):
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(pady=15, padx=15, fill="both", expand=True)
        self.tab_dashboard = ttk.Frame(self.notebook, padding=15)
        self.notebook.add(self.tab_dashboard, text="Dashboard")
        self.create_dashboard_tab()
        self.tab_books = ttk.Frame(self.notebook, padding=15)
        self.notebook.add(self.tab_books, text="Manage Books")
        self.create_books_tab()
        self.tab_members = ttk.Frame(self.notebook, padding=15)
        self.notebook.add(self.tab_members, text="Manage Members")
        self.create_members_tab()
        self.tab_borrow = ttk.Frame(self.notebook, padding=15)
        self.notebook.add(self.tab_borrow, text="Borrow/Return")
        self.create_borrow_return_tab()
    def create_dashboard_tab(self):
        refresh_frame = ttk.Frame(self.tab_dashboard)
        refresh_frame.pack(fill='x', pady=5)
        ttk.Label(refresh_frame, text="Current library status.", style="Title.TLabel").pack(side=tk.LEFT)
        self.btn_refresh_all = ttk.Button(refresh_frame, text="Refresh All Data", style="Modern.TButton", command=self.refresh_all_tables)
        self.btn_refresh_all.pack(side=tk.RIGHT)

        avail_books_frame = ttk.LabelFrame(self.tab_dashboard, text="Available Books", padding=15)
        avail_books_frame.pack(fill="both", expand=True, pady=10)
        self.avail_books_tree = self.create_treeview(avail_books_frame, 
            columns=("id", "title", "author", "isbn"),
            headings=("Book ID", "Title", "Author", "ISBN"))
        
        borrowed_books_frame = ttk.LabelFrame(self.tab_dashboard, text="Currently Borrowed Books", padding=15)
        borrowed_books_frame.pack(fill="both", expand=True, pady=10)
        self.borrowed_books_tree = self.create_treeview(borrowed_books_frame,
            columns=("book_id", "title", "member_id", "member_name", "borrow_date", "due_date"),
            headings=("Book ID", "Title", "Member ID", "Member Name", "Borrowed On", "Due Date"))
        
        for col in ("book_id", "member_id"): self.borrowed_books_tree.column(col, width=80)
        for col in ("title", "member_name"): self.borrowed_books_tree.column(col, width=200)
        for col in ("borrow_date", "due_date"): self.borrowed_books_tree.column(col, width=120)

    def create_books_tab(self):
        forms_frame = ttk.Frame(self.tab_books)
        forms_frame.pack(fill='x', pady=5)

        add_frame = ttk.LabelFrame(forms_frame, text="Add New Book", padding=15)
        add_frame.pack(side=tk.LEFT, fill='x', expand=True, padx=(0, 10), pady=10)

        ttk.Label(add_frame, text="Title:").grid(row=0, column=0, padx=10, pady=8, sticky='w')
        self.entry_book_title = ttk.Entry(add_frame, width=45)
        self.entry_book_title.grid(row=0, column=1, padx=10, pady=8)
        
        ttk.Label(add_frame, text="Author:").grid(row=1, column=0, padx=10, pady=8, sticky='w')
        self.entry_book_author = ttk.Entry(add_frame, width=45)
        self.entry_book_author.grid(row=1, column=1, padx=10, pady=8)
        
        ttk.Label(add_frame, text="ISBN:").grid(row=2, column=0, padx=10, pady=8, sticky='w')
        self.entry_book_isbn = ttk.Entry(add_frame, width=45)
        self.entry_book_isbn.grid(row=2, column=1, padx=10, pady=8)
        
        self.btn_add_book = ttk.Button(add_frame, text="Add Book", style="Modern.TButton", command=self.add_book)
        self.btn_add_book.grid(row=3, column=0, columnspan=2, pady=15)
        
        delete_frame = ttk.LabelFrame(forms_frame, text="Delete Book", padding=15)
        delete_frame.pack(side=tk.LEFT, fill='x', expand=True, padx=(10, 0), pady=10)

        ttk.Label(delete_frame, text="Book ID:").grid(row=0, column=0, padx=10, pady=8, sticky='w')
        self.entry_delete_book_id = ttk.Entry(delete_frame, width=25)
        self.entry_delete_book_id.grid(row=0, column=1, padx=10, pady=8)

        self.btn_delete_book = ttk.Button(delete_frame, text="Delete Book", style="Modern.TButton", command=self.delete_book)
        self.btn_delete_book.grid(row=1, column=0, columnspan=2, pady=15)

        all_books_frame = ttk.LabelFrame(self.tab_books, text="All Books in Library", padding=15)
        all_books_frame.pack(fill="both", expand=True, pady=10)
        self.all_books_tree = self.create_treeview(all_books_frame,
            columns=("id", "title", "author", "isbn", "status"),
            headings=("Book ID", "Title", "Author", "ISBN", "Status"))
        
        self.all_books_tree.column("id", width=80)
        self.all_books_tree.column("status", width=100)
        self.all_books_tree.column("title", width=250)
        self.all_books_tree.column("author", width=200)

    def create_members_tab(self):
        forms_frame = ttk.Frame(self.tab_members)
        forms_frame.pack(fill='x', pady=5)
        
        add_frame = ttk.LabelFrame(forms_frame, text="Add New Member", padding=15)
        add_frame.pack(side=tk.LEFT, fill='x', expand=True, padx=(0, 10), pady=10)

        ttk.Label(add_frame, text="Name:").grid(row=0, column=0, padx=10, pady=8, sticky='w')
        self.entry_member_name = ttk.Entry(add_frame, width=45)
        self.entry_member_name.grid(row=0, column=1, padx=10, pady=8)
        
        ttk.Label(add_frame, text="Email:").grid(row=1, column=0, padx=10, pady=8, sticky='w')
        self.entry_member_email = ttk.Entry(add_frame, width=45)
        self.entry_member_email.grid(row=1, column=1, padx=10, pady=8)
        
        self.btn_add_member = ttk.Button(add_frame, text="Add Member", style="Modern.TButton", command=self.add_member)
        self.btn_add_member.grid(row=2, column=0, columnspan=2, pady=15)

        delete_frame = ttk.LabelFrame(forms_frame, text="Delete Member", padding=15)
        delete_frame.pack(side=tk.LEFT, fill='x', expand=True, padx=(10, 0), pady=10)

        ttk.Label(delete_frame, text="Member ID:").grid(row=0, column=0, padx=10, pady=8, sticky='w')
        self.entry_delete_member_id = ttk.Entry(delete_frame, width=25)
        self.entry_delete_member_id.grid(row=0, column=1, padx=10, pady=8)

        self.btn_delete_member = ttk.Button(delete_frame, text="Delete Member", style="Modern.TButton", command=self.delete_member)
        self.btn_delete_member.grid(row=1, column=0, columnspan=2, pady=15)

        all_members_frame = ttk.LabelFrame(self.tab_members, text="All Members", padding=15)
        all_members_frame.pack(fill="both", expand=True, pady=10)
        self.all_members_tree = self.create_treeview(all_members_frame,
            columns=("id", "name", "email"),
            headings=("Member ID", "Name", "Email"))
        
        self.all_members_tree.column("id", width=100)
        self.all_members_tree.column("name", width=250)
        self.all_members_tree.column("email", width=300)

    def create_borrow_return_tab(self):
        actions_frame = ttk.Frame(self.tab_borrow)
        actions_frame.pack(fill='x', pady=5)

        borrow_frame = ttk.LabelFrame(actions_frame, text="Borrow a Book", padding=15)
        borrow_frame.pack(side=tk.LEFT, fill='x', expand=True, padx=(0, 10), pady=10)

        ttk.Label(borrow_frame, text="Book ID:").grid(row=0, column=0, padx=10, pady=8, sticky='w')
        self.entry_borrow_book_id = ttk.Entry(borrow_frame, width=20)
        self.entry_borrow_book_id.grid(row=0, column=1, padx=10, pady=8)
        
        ttk.Label(borrow_frame, text="Member ID:").grid(row=1, column=0, padx=10, pady=8, sticky='w')
        self.entry_borrow_member_id = ttk.Entry(borrow_frame, width=20)
        self.entry_borrow_member_id.grid(row=1, column=1, padx=10, pady=8)
        
        self.btn_borrow_book = ttk.Button(borrow_frame, text="Borrow Book", style="Modern.TButton", command=self.borrow_book)
        self.btn_borrow_book.grid(row=2, column=0, columnspan=2, pady=15)
        
        return_frame = ttk.LabelFrame(actions_frame, text="Return a Book", padding=15)
        return_frame.pack(side=tk.LEFT, fill='x', expand=True, padx=(10, 0), pady=10)

        ttk.Label(return_frame, text="Book ID:").grid(row=0, column=0, padx=10, pady=8, sticky='w')
        self.entry_return_book_id = ttk.Entry(return_frame, width=20)
        self.entry_return_book_id.grid(row=0, column=1, padx=10, pady=8)
        
        self.btn_return_book = ttk.Button(return_frame, text="Return Book", style="Modern.TButton", command=self.return_book)
        self.btn_return_book.grid(row=1, column=0, columnspan=2, pady=15)

    def create_treeview(self, parent, columns, headings):
        tree_scroll = ttk.Scrollbar(parent, orient="vertical")
        tree_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        tree = ttk.Treeview(parent, yscrollcommand=tree_scroll.set, columns=columns, show="headings")
        tree.pack(fill="both", expand=True)
        tree_scroll.config(command=tree.yview)
        
        for col, heading in zip(columns, headings):
            tree.heading(col, text=heading, anchor=tk.W)
            tree.column(col, width=100, anchor=tk.W)

        tree.tag_configure('oddrow', background=self.BG_COLOR)
        tree.tag_configure('evenrow', background=self.ALT_ROW_COLOR)
            
        return tree
        
    def populate_treeview(self, tree, data_fetch_func):
        for item in tree.get_children():
            tree.delete(item)
        try:
            data = data_fetch_func()
            for i, row in enumerate(data):
                tag = 'evenrow' if i % 2 == 0 else 'oddrow'
                tree.insert('', 'end', values=row, tags=(tag,))
        except Exception as e:
            messagebox.showerror("Load Error", f"Failed to load data: {e}")

    def refresh_all_tables(self):
        self.populate_treeview(self.avail_books_tree, self.db.view_available_books)
        self.populate_treeview(self.borrowed_books_tree, self.db.view_borrowed_books)
        self.populate_treeview(self.all_books_tree, self.db.view_all_books)
        self.populate_treeview(self.all_members_tree, self.db.view_all_members)
    def add_book(self):
        title = self.entry_book_title.get()
        author = self.entry_book_author.get()
        isbn = self.entry_book_isbn.get()
        
        success, message = self.db.add_book(title, author, isbn)
        if success:
            messagebox.showinfo("Success", message)
            self.entry_book_title.delete(0, tk.END)
            self.entry_book_author.delete(0, tk.END)
            self.entry_book_isbn.delete(0, tk.END)
            self.refresh_all_tables()
        else:
            messagebox.showerror("Error", message)

    def add_member(self):
        name = self.entry_member_name.get()
        email = self.entry_member_email.get()
        
        success, message = self.db.add_member(name, email)
        if success:
            messagebox.showinfo("Success", message)
            self.entry_member_name.delete(0, tk.END)
            self.entry_member_email.delete(0, tk.END)
            self.refresh_all_tables()
        else:
            messagebox.showerror("Error", message)

    def borrow_book(self):
        book_id = self.entry_borrow_book_id.get()
        member_id = self.entry_borrow_member_id.get()
        
        if not book_id or not member_id:
            messagebox.showwarning("Input Error", "Book ID and Member ID are required.")
            return

        success, message = self.db.borrow_book(book_id, member_id)
        if success:
            messagebox.showinfo("Success", message)
            self.entry_borrow_book_id.delete(0, tk.END)
            self.entry_borrow_member_id.delete(0, tk.END)
            self.refresh_all_tables()
        else:
            messagebox.showerror("Error", message)

    def return_book(self):
        book_id = self.entry_return_book_id.get()
        
        if not book_id:
            messagebox.showwarning("Input Error", "Book ID is required.")
            return

        success, message = self.db.return_book(book_id)
        if success:
            messagebox.showinfo("Success", message)
            self.entry_return_book_id.delete(0, tk.END)
            self.refresh_all_tables()
        else:
            messagebox.showerror("Error", message)

    def delete_book(self):
        book_id = self.entry_delete_book_id.get()
        if not book_id:
            messagebox.showwarning("Input Error", "Please enter a Book ID to delete.")
            return

        if not messagebox.askyesno("Confirm Deletion", f"Are you sure you want to PERMANENTLY delete book ID {book_id}?"):
            return
            
        success, message = self.db.delete_book(book_id)
        if success:
            messagebox.showinfo("Success", message)
            self.entry_delete_book_id.delete(0, tk.END)
            self.refresh_all_tables()
        else:
            messagebox.showerror("Error", message)

    def delete_member(self):
        member_id = self.entry_delete_member_id.get()
        if not member_id:
            messagebox.showwarning("Input Error", "Please enter a Member ID to delete.")
            return

        if not messagebox.askyesno("Confirm Deletion", f"Are you sure you want to PERMANENTLY delete member ID {member_id}?"):
            return

        success, message = self.db.delete_member(member_id)
        if success:
            messagebox.showinfo("Success", message)
            self.entry_delete_member_id.delete(0, tk.END)
            self.refresh_all_tables()
        else:
            messagebox.showerror("Error", message)

if __name__ == "__main__":

    app = LoginPage()
    app.mainloop()