import sqlite3
import datetime
import hashlib

class LibraryManagementSystem:

    def __init__(self, db_name="library.db"):
        self.db_name = db_name
        self.conn = sqlite3.connect(self.db_name)
        self.cursor = self.conn.cursor()
        self.create_tables()

    def create_tables(self):
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS books (
            book_id INTEGER PRIMARY KEY ,
            title TEXT NOT NULL,
            author TEXT NOT NULL,
            isbn TEXT UNIQUE,
            status TEXT DEFAULT 'Available'
        )
        ''')
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS members (
            member_id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT
        )
        ''')
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS borrowed_books (
            borrow_id INTEGER PRIMARY KEY AUTOINCREMENT,
            book_id INTEGER NOT NULL,
            member_id INTEGER NOT NULL,
            borrow_date TEXT NOT NULL,
            due_date TEXT NOT NULL,
            FOREIGN KEY (book_id) REFERENCES books (book_id),
            FOREIGN KEY (member_id) REFERENCES members (member_id)
        )
        ''')
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL
        )
        ''')
        
        self.conn.commit()

    def _hash_password(self, password):
        return hashlib.sha256(password.encode('utf-8')).hexdigest()

    def register_user(self, username, password):
        if not username or not password:
            return (False, "Error: Username and password are required.")
        
        hashed_pw = self._hash_password(password)
        
        try:
            self.cursor.execute(
                "INSERT INTO users (username, password_hash) VALUES (?, ?)",
                (username, hashed_pw)
            )
            self.conn.commit()
            return (True, f"Success: User '{username}' registered.")
        except sqlite3.IntegrityError:
            return (False, f"Error: Username '{username}' is already taken.")
        except Exception as e:
            return (False, f"An unexpected error occurred: {e}")

    def login_user(self, username, password):
        if not username or not password:
            return False
            
        hashed_pw = self._hash_password(password)
        
        self.cursor.execute(
            "SELECT 1 FROM users WHERE username = ? AND password_hash = ?",
            (username, hashed_pw)
        )
        result = self.cursor.fetchone()
        
        return result is not None
    def add_book(self, title, author, isbn):
        try:
            if not title or not author:
                return (False, "Error: Title and Author are required.")
            
            self.cursor.execute(
                "INSERT INTO books (title, author, isbn, status) VALUES (?, ?, ?, 'Available')",
                (title, author, isbn)
            )
            self.conn.commit()
            new_id = self.cursor.lastrowid
            return (True, f"Success: Book '{title}' added with ID {new_id}.")
        except sqlite3.IntegrityError:
            return (False, f"Error: A book with ISBN {isbn} already exists.")
        except Exception as e:
            return (False, f"An unexpected error occurred: {e}")

    def view_all_books(self):
        self.cursor.execute("SELECT book_id, title, author, isbn, status FROM books")
        return self.cursor.fetchall()
        
    def view_available_books(self):
        self.cursor.execute("SELECT book_id, title, author, isbn FROM books WHERE status = 'Available'")
        return self.cursor.fetchall()

    def find_book(self, book_id):
        try:
            b_id = int(book_id)
            self.cursor.execute("SELECT * FROM books WHERE book_id = ?", (b_id,))
            return self.cursor.fetchone()
        except ValueError:
            return None

    def delete_book(self, book_id):
        try:
            b_id = int(book_id)
            book = self.find_book(b_id)
            if not book:
                return (False, f"Error: Book with ID {b_id} does not exist.")
            if book[4] == 'Borrowed':
                return (False, f"Error: Book ID {b_id} is currently borrowed. Return it before deleting.")
            self.cursor.execute("DELETE FROM books WHERE book_id = ?", (b_id,))
            self.conn.commit()
            
            return (True, f"Success: Book ID {b_id} ('{book[1]}') has been deleted.")

        except ValueError:
            return (False, "Error: Book ID must be a number.")
        except Exception as e:
            self.conn.rollback()
            return (False, f"An error occurred: {e}")
    def add_member(self, name, email):
        try:
            if not name:
                return (False, "Error: Member name is required.")
            
            self.cursor.execute(
                "INSERT INTO members (name, email) VALUES (?, ?)",
                (name, email)
            )
            self.conn.commit()
            new_id = self.cursor.lastrowid
            return (True, f"Success: Member '{name}' added with ID {new_id}.")
        except Exception as e:
            return (False, f"An unexpected error occurred: {e}")

    def view_all_members(self):
        self.cursor.execute("SELECT member_id, name, email FROM members")
        return self.cursor.fetchall()

    def find_member(self, member_id):
        try:
            m_id = int(member_id)
            self.cursor.execute("SELECT * FROM members WHERE member_id = ?", (m_id,))
            return self.cursor.fetchone()
        except ValueError:
            return None

    def _member_has_borrows(self, member_id):
        self.cursor.execute("SELECT 1 FROM borrowed_books WHERE member_id = ?", (member_id,))
        return self.cursor.fetchone() is not None

    def delete_member(self, member_id):
        try:
            m_id = int(member_id)
            member = self.find_member(m_id)
            if not member:
                return (False, f"Error: Member with ID {m_id} does not exist.")
            if self._member_has_borrows(m_id):
                return (False, f"Error: Member ID {m_id} has borrowed books. Return all books before deleting member.")
            self.cursor.execute("DELETE FROM members WHERE member_id = ?", (m_id,))
            self.conn.commit()
            
            return (True, f"Success: Member ID {m_id} ('{member[1]}') has been deleted.")

        except ValueError:
            return (False, "Error: Member ID must be a number.")
        except Exception as e:
            self.conn.rollback()
            return (False, f"An error occurred: {e}")
    def borrow_book(self, book_id, member_id):
        try:
            b_id = int(book_id)
            m_id = int(member_id)
            book = self.find_book(b_id)
            if not book:
                return (False, f"Error: Book with ID {b_id} does not exist.")
            if book[4] != 'Available':
                return (False, f"Error: Book '{book[1]}' is currently {book[4]}.")
            if not self.find_member(m_id):
                return (False, f"Error: Member with ID {m_id} does not exist.")
            borrow_date = datetime.date.today()
            due_date = borrow_date + datetime.timedelta(days=14)
            
            self.conn.execute("BEGIN")
            self.cursor.execute(
                "INSERT INTO borrowed_books (book_id, member_id, borrow_date, due_date) VALUES (?, ?, ?, ?)",
                (b_id, m_id, borrow_date.isoformat(), due_date.isoformat())
            )
            self.cursor.execute("UPDATE books SET status = 'Borrowed' WHERE book_id = ?", (b_id,))
            self.conn.commit()
            
            return (True, f"Success: Book ID {b_id} borrowed by Member ID {m_id}. Due: {due_date.isoformat()}")

        except ValueError:
            return (False, "Error: Book ID and Member ID must be numbers.")
        except Exception as e:
            self.conn.rollback()
            return (False, f"An error occurred: {e}")

    def return_book(self, book_id):
        try:
            b_id = int(book_id)
            
            book = self.find_book(b_id)
            if not book:
                return (False, f"Error: Book with ID {b_id} does not exist.")
            if book[4] != 'Borrowed':
                return (False, f"Error: Book '{book[1]}' is not currently borrowed.")

            self.conn.execute("BEGIN")
            self.cursor.execute("UPDATE books SET status = 'Available' WHERE book_id = ?", (b_id,))
            self.cursor.execute("DELETE FROM borrowed_books WHERE book_id = ?", (b_id,))
            self.conn.commit()

            return (True, f"Success: Book ID {b_id} ('{book[1]}') has been returned.")
            
        except ValueError:
            return (False, "Error: Book ID must be a number.")
        except Exception as e:
            self.conn.rollback()
            return (False, f"An error occurred: {e}")

    def view_borrowed_books(self):
        self.cursor.execute('''
        SELECT b.book_id, b.title, m.member_id, m.name, bb.borrow_date, bb.due_date
        FROM borrowed_books AS bb
        JOIN books AS b ON bb.book_id = b.book_id
        JOIN members AS m ON bb.member_id = m.member_id
        ''')
        return self.cursor.fetchall()

    def __del__(self):
        if self.conn:
            self.conn.close()